-- Generado por Oracle SQL Developer Data Modeler 23.1.0.087.0806
--   en:        2025-01-18 19:47:24 PET
--   sitio:      Oracle Database 11g
--   tipo:      Oracle Database 11g



-- predefined type, no DDL - MDSYS.SDO_GEOMETRY

-- predefined type, no DDL - XMLTYPE

CREATE TABLE tabla_capacidad (
    capacidadid     NUMBER(2) NOT NULL,
    capacidaddiaria NUMBER(4) NOT NULL,
    capacidadanual  NUMBER(8) NOT NULL,
    funciondiaid    NUMBER(2) NOT NULL,
    salaid          NUMBER(2) NOT NULL
);

ALTER TABLE tabla_capacidad ADD CONSTRAINT pk_capacidad PRIMARY KEY ( capacidadid );

CREATE TABLE tabla_capacidad_sala (
    capacidadsalaid NUMBER(2) NOT NULL,
    numerosalas     NUMBER(3) NOT NULL,
    empresaid       NUMBER(2) NOT NULL
);

ALTER TABLE tabla_capacidad_sala ADD CONSTRAINT pk_capacidadsala PRIMARY KEY ( capacidadsalaid );

CREATE TABLE tabla_categoria_cliente (
    categoriaclienteid NUMBER(2) NOT NULL,
    nombrecategoria    VARCHAR2(200 BYTE) NOT NULL
);

ALTER TABLE tabla_categoria_cliente ADD CONSTRAINT pk_categoriacliente PRIMARY KEY ( categoriaclienteid );

CREATE TABLE tabla_empresa (
    empresaid     NUMBER(2) NOT NULL,
    nombreempresa VARCHAR2(200 BYTE) NOT NULL
);

ALTER TABLE tabla_empresa ADD CONSTRAINT pk_empresa PRIMARY KEY ( empresaid );

CREATE TABLE tabla_factor (
    factorid   NUMBER(2) NOT NULL,
    tipofactor VARCHAR2(100 BYTE) NOT NULL
);

ALTER TABLE tabla_factor ADD CONSTRAINT pk_factor PRIMARY KEY ( factorid );

CREATE TABLE tabla_factor_compra (
    factorcompraid NUMBER(2) NOT NULL,
    factorcompra   VARCHAR2(200 BYTE) NOT NULL,
    factorid       NUMBER(2) NOT NULL
);

ALTER TABLE tabla_factor_compra ADD CONSTRAINT pk_factorcompra PRIMARY KEY ( factorcompraid );

CREATE TABLE tabla_funcion (
    tipofuncionid NUMBER(2) NOT NULL,
    nombrefuncion VARCHAR2(200 BYTE) NOT NULL
);

ALTER TABLE tabla_funcion ADD CONSTRAINT pk_funcion PRIMARY KEY ( tipofuncionid );

CREATE TABLE tabla_funcion_dia (
    funciondiaid    NUMBER(2) NOT NULL,
    numerofunciones NUMBER(2) NOT NULL
);

ALTER TABLE tabla_funcion_dia ADD CONSTRAINT pk_funciondia PRIMARY KEY ( funciondiaid );

CREATE TABLE tabla_modelo (
    modeloid     NUMBER(2) NOT NULL,
    nombremodelo VARCHAR2(200 BYTE) NOT NULL
);

ALTER TABLE tabla_modelo ADD CONSTRAINT pk_modelo PRIMARY KEY ( modeloid );

CREATE TABLE tabla_sala (
    salaid            NUMBER(2) NOT NULL,
    capacidadpromedio NUMBER(2) NOT NULL,
    capacidadsalaid   NUMBER(2) NOT NULL
);

ALTER TABLE tabla_sala ADD CONSTRAINT pk_sala PRIMARY KEY ( salaid );

CREATE TABLE tabla_tipo_entrada (
    tipoentradaid     NUMBER(3) NOT NULL,
    nombretipoentrada VARCHAR2(200 BYTE) NOT NULL
);

ALTER TABLE tabla_tipo_entrada ADD CONSTRAINT pk_tipoentrada PRIMARY KEY ( tipoentradaid );

CREATE TABLE tabla_tipo_tarifa (
    tarifaid   NUMBER(2) NOT NULL,
    tipotarifa VARCHAR2(200 BYTE) NOT NULL
);

ALTER TABLE tabla_tipo_tarifa ADD CONSTRAINT pk_tipotarifa PRIMARY KEY ( tarifaid );

CREATE TABLE tabla_ventas (
    ventaid             NUMBER(4) NOT NULL,
    preciobase          NUMBER NOT NULL,
    multiplicador       VARCHAR2(50 BYTE) NOT NULL,
    nuevoprecio         NUMBER NOT NULL,
    ventatotal          NUMBER(8) NOT NULL,
    capacidadid         NUMBER(2) NOT NULL,
    factorcompraid      NUMBER(2) NOT NULL,
    tipoentradaid       NUMBER(3) NOT NULL,
    modeloid            NUMBER(2) NOT NULL,
    categoriaclienteid  NUMBER(2) NOT NULL,
    tarifaid            NUMBER(2) NOT NULL,
    totalclientes       NUMBER(6) NOT NULL,
    porcentajeocupacion NUMBER NOT NULL,
    tipofuncionid       NUMBER(2) NOT NULL
);

ALTER TABLE tabla_ventas ADD CONSTRAINT pk_tabla_ventas PRIMARY KEY ( ventaid );

ALTER TABLE tabla_capacidad
    ADD CONSTRAINT fk_capacidad_funciondia FOREIGN KEY ( funciondiaid )
        REFERENCES tabla_funcion_dia ( funciondiaid )
            ON DELETE CASCADE;

ALTER TABLE tabla_capacidad
    ADD CONSTRAINT fk_capacidad_sala FOREIGN KEY ( salaid )
        REFERENCES tabla_sala ( salaid )
            ON DELETE CASCADE;

ALTER TABLE tabla_capacidad_sala
    ADD CONSTRAINT fk_capacidadsala_empresa FOREIGN KEY ( empresaid )
        REFERENCES tabla_empresa ( empresaid )
            ON DELETE CASCADE;

ALTER TABLE tabla_factor_compra
    ADD CONSTRAINT fk_factorcompra_factor FOREIGN KEY ( factorid )
        REFERENCES tabla_factor ( factorid )
            ON DELETE CASCADE;

ALTER TABLE tabla_sala
    ADD CONSTRAINT fk_sala_capacidadsala FOREIGN KEY ( capacidadsalaid )
        REFERENCES tabla_capacidad_sala ( capacidadsalaid )
            ON DELETE CASCADE;

ALTER TABLE tabla_ventas
    ADD CONSTRAINT fk_ventas_capacidad FOREIGN KEY ( capacidadid )
        REFERENCES tabla_capacidad ( capacidadid )
            ON DELETE CASCADE;

ALTER TABLE tabla_ventas
    ADD CONSTRAINT fk_ventas_categoriacliente FOREIGN KEY ( categoriaclienteid )
        REFERENCES tabla_categoria_cliente ( categoriaclienteid )
            ON DELETE CASCADE;

ALTER TABLE tabla_ventas
    ADD CONSTRAINT fk_ventas_factorcompra FOREIGN KEY ( factorcompraid )
        REFERENCES tabla_factor_compra ( factorcompraid )
            ON DELETE CASCADE;

ALTER TABLE tabla_ventas
    ADD CONSTRAINT fk_ventas_funcion FOREIGN KEY ( tipofuncionid )
        REFERENCES tabla_funcion ( tipofuncionid )
            ON DELETE CASCADE;

ALTER TABLE tabla_ventas
    ADD CONSTRAINT fk_ventas_modelo FOREIGN KEY ( modeloid )
        REFERENCES tabla_modelo ( modeloid )
            ON DELETE CASCADE;

ALTER TABLE tabla_ventas
    ADD CONSTRAINT fk_ventas_tipoentrada FOREIGN KEY ( tipoentradaid )
        REFERENCES tabla_tipo_entrada ( tipoentradaid )
            ON DELETE CASCADE;

ALTER TABLE tabla_ventas
    ADD CONSTRAINT fk_ventas_tipotarifa FOREIGN KEY ( tarifaid )
        REFERENCES tabla_tipo_tarifa ( tarifaid )
            ON DELETE CASCADE;



-- Informe de Resumen de Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                            13
-- CREATE INDEX                             0
-- ALTER TABLE                             25
-- CREATE VIEW                              0
-- ALTER VIEW                               0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE MATERIALIZED VIEW LOG             0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ORDS DROP SCHEMA                         0
-- ORDS ENABLE SCHEMA                       0
-- ORDS ENABLE OBJECT                       0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
